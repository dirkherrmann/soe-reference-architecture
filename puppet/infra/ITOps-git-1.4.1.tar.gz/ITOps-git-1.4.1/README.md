# Puppet module for managing git

Installs and configures git.

