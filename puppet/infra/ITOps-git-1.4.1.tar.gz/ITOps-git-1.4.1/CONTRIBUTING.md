Checklist (and a short version for the impatient)
=================================================

