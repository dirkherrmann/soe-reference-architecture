# Changelog

## 1.4.1
* Add minimal tests, increased linting
* Fixes to metadata quality

## 1.4.0
* Parameterize 'git' class, add package_ensure parameter

## 1.3.2
* Run git from a temporary working directory to avoid cwd errors

## 1.3.1
* Always default to 'git' package, fix related bugs
