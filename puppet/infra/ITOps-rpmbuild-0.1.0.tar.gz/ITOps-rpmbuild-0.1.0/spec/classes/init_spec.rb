require 'spec_helper'
describe 'rpmbuild' do

  context 'with defaults for all parameters' do
    it { should contain_class('rpmbuild') }
  end
end
