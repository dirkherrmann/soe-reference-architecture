require 'spec_helper'
describe 'acmeweb' do

  context 'with defaults for all parameters' do
    it { should contain_class('acmeweb') }
  end
end
